# Explore and Summarize Data   Udacity DAND Project
Author: Ameenah Naytah


Project Overview

In this project, you will use R and apply exploratory data analysis techniques in a selected dataset to discover relationships among multiple variables, and create explanatory visualizations illuminating distributions, outliers, and anomalies.


Project Submission
Use R and apply exploratory data analysis techniques to explore relationships in one variable to multiple variables and to explore a selected data set for distributions, outliers, and anomalies.
